<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Foundation\Auth\User;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class KYC2VerifyReject extends Notification
{
    use Queueable;
    public $user;
    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct(User $user)
    {
        //
        $this->user = $user;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {

        $user = $this->user;

        return (new MailMessage)

            ->subject('Proof of Address Verify Request Denied')
            ->greeting('Sorry '. $user->name.'!')
            ->line("Unfortunately We can't verify your Proof of Address. You have 3 attempts to do. After 3 request you will get permanently banned. Please send us clear photo with english language then we can verify.")
            ->line("Also need accurate and real identity info. Must be document age not be 3 months old. We don't want to business with anonymous user. To submit another application please login in your account. For login click login now button below. ")
            ->action('Login Now', route('login'))
            ->line('Thank you for using our website! If you face any problem feel free to contact us anytime.');


    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
