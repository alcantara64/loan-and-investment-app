<div class="features-1">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <h2 class="title">Why We Are The Best?</h2>
            <h5 class="description">Anyone can make investments using our website. The interface is so easy to use that even someone with zero experience can figure it out. In addition, our experts are available online 24/7 and are always ready to help. Trust management with TrustedPaidAds.com . We help our clients earn money on the volatility of the Finance market. Today, this is an industry with a market capitalization of $130,654,12</h5>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="info">
                <div class="icon icon-info">
                    <i class="material-icons">chat</i>
                </div>
                <h4 class="info-title">24/7 Support</h4>
                <p>Trusted Paid Ads Support Team experts are always here to answer your questions. You can ask them any time of the day and receive a prompt response.</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="info">
                <div class="icon icon-success">
                    <i class="material-icons">verified_user</i>
                </div>
                <h4 class="info-title">Registered Company</h4>
                <p>We are Real United Kingdom Based Company. We Don't Support Scam and We do not. We are government verified company. We have License to do this business and Leading This.</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="info">
                <div class="icon icon-primary">
                    <i class="material-icons">lock</i>
                </div>
                <h4 class="info-title">Security</h4>
                <p>Our website resides on a dedicated server with DDoS protection and SSL certificates, so attacks are virtually impossible. You can access your personal dashboard anytime, anywhere – 24/7.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="info">
                <div class="icon icon-danger">
                    <i class="material-icons">gavel</i>
                </div>
                <h4 class="info-title">Privacy</h4>
                <p>We don't require identity verification. Information about your activity on the website is private and can't be accessed by third parties.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="info">
                <div class="icon icon-info">
                    <i class="material-icons">directions_bike</i>
                </div>
                <h4 class="info-title">Easy To Use</h4>
                <p>Just a few click your order is ready. Once you deposit, your coin starts to multiply right away. It is designed to be user friendly and easy to operate for both professionals and new investors.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="info">
                <div class="icon icon-primary">
                    <i class="material-icons">local_atm</i>
                </div>
                <h4 class="info-title">Professional</h4>
                <p>Seize the opportunity to grow your capital in the most liquid market in the world by copying the trades of top preforming traders in our investment programme.</p>
            </div>
        </div>
    </div>

</div>