<?php $__env->startSection('title', $page->title); ?>

<?php $__env->startSection('content'); ?>


    <body class="section-white">
    <div class="cd-section" id="headers">
        <div class="header-1">
            <nav class="navbar navbar-info navbar-transparent navbar-fixed-top navbar-color-on-scroll">
                <?php echo $__env->make('includes.public.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </nav>
            <div class="page-header header-filter" style="background-image: url('<?php echo e(asset('img/bg12.jpg')); ?>');">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <h1 class="title">Get Paid to Surf</h1>
                            <h4>Are you ready to start making money online with little effort? We are an ideal get-paid-to website that you can trust. We have been around for a while and we actually pay! Don't waste your time with scam sites, join CronLab PTC today and start earning real cash now!</h4>
                            <br />

                            <?php if(Auth::check()): ?>

                                <a href="#" target="_blank" class="btn btn-success btn-lg">
                                    <i class="fa fa-ticket"></i> View Ads Now
                                </a>

                            <?php else: ?>


                                <a href="<?php echo e(url('/register')); ?>" target="_self" class="btn btn-primary btn-lg">
                                    <i class="fa fa-ticket"></i> Join Now
                                </a>


                            <?php endif; ?>

                        </div>

                        <?php if(env('BLOG_YOUTUBE_EMBED_CODE')): ?>

                            <div class="col-md-5 col-md-offset-1">
                                <div class="iframe-container">
                                    <iframe src="https://www.youtube.com/embed/<?php echo e(env('BLOG_YOUTUBE_EMBED_CODE')); ?>?modestbranding=1&amp;autohide=1&amp;showinfo=0" frameborder="0" allowfullscreen height="250"></iframe>
                                </div>
                            </div>

                        <?php else: ?>


                        <?php endif; ?>


                    </div>
                </div>
            </div>

        </div>

        <!--     *********    END HEADER 3      *********      -->
    </div>

    <div class="main main-raised">
        <div class="container">
            <div class="section section-text">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <h3 class="title"><?php echo e($page->title); ?></h3>
                        <p>Last Update <?php echo e($page->updated_at->diffForHumans()); ?></p>
                        <br>

                        <?php echo $page->content; ?>


                    </div>
                </div>
            </div>



        </div>
    </div>


    <footer class="footer">


        <?php echo $__env->make('includes.public.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    </footer>

    </body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>