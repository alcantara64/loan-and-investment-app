<?php $__env->startSection('title', 'All Website FAQ'); ?>


<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-md-7">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">contacts</i>
                </div>
                <br>
                <h4 class="card-title">All Website FAQ</h4>
                <div class="card-content">
                    <br>


                    <div class="table-responsive">

                        <table class="table">
                            <thead>
                            <tr>
                                <th class="text-center">ID</th>
                                <th class="text-center">Question</th>
                                <th class="text-center">Solution</th>
                                <th class="text-center">Edit</th>
                                <th class="text-center">Actions</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php if($faqs): ?>
                                <?php $id=0;?>
                                <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $id++;?>
                                    <tr>
                                        <td class="text-center"><?php echo e($id); ?></td>
                                        <td class="text-center"><?php echo e($faq->title); ?></td>
                                        <td class="text-center"><?php echo Markdown::convertToHtml(str_limit($faq->content,'100')); ?></td>
                                        <td class="td-actions text-center">
                                            <a href="<?php echo e(route('adminFAQEdit', $faq->id)); ?>" type="button" rel="tooltip" class="btn btn-success">
                                                <i class="material-icons">edit</i>
                                            </a>
                                        </td>
                                        <td class="td-actions text-center">
                                            <a href="<?php echo e(route('adminFAQDestroy', $faq->id)); ?>" type="button" rel="tooltip" class="btn btn-danger">
                                                <i class="material-icons">close</i>
                                            </a>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-5">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">contacts</i>
                </div>
                <br>
                <h4 class="card-title">Create Frequently Ask Question</h4>
                <div class="card-content">
                    <br>

                    <form class="m-form" action="<?php echo e(route('adminFAQStore')); ?>" method="post">

                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger alert-with-icon" data-notify="container">
                                <i class="material-icons" data-notify="icon">notifications</i>
                                <span data-notify="message">

                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><strong> <?php echo e($error); ?> </strong></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </span>
                            </div>
                        <?php endif; ?>
                        <div class="row">

                            <div class="col-md-12">

                                <div class="form-group">
                                    <div class="form-group label-floating">

                                        <label  class="control-label" for="title">F.A.Q Title Question</label>
                                        <input id="title" name="title" type="text" class="form-control">

                                    </div>

                                </div>

                            </div>
                        </div>
                        <br>
                        <div class="row">

                            <div class="col-md-12">

                                <div class="form-group">
                                    <div class="form-group label-floating">

                                        <label  class="control-label" for="content">F.A.Q Question Solution</label>
                                        <textarea class="form-control" name="body" id="content" rows="10"></textarea>

                                    </div>

                                </div>

                            </div>
                        </div>

                        <button type="submit" class="btn btn-success pull-right">Create F.A.Q</button>

                        <div class="clearfix"></div>
                    </form>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>