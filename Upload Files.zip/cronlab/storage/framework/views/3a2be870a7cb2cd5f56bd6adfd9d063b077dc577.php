<?php $__env->startSection('title', $inbox->subject); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3 text-center">
                        <h2 class="title"> View Emails</h2>
                        <h5 class="description">My Email : <?php echo e($inbox->email); ?></h5>
                    </div>
                </div>


                <div class="card-content">
                    <br>
                            <div class="col-md-10 col-md-offset-1">
                                <div class="card card-pricing card-raised">
                                    <div class="card-content">
                                        <h6 class="category">My Name : <?php echo e($inbox->name); ?></h6>
                                        <div class="icon icon-info">
                                            <i class="material-icons">mail_outline</i>
                                        </div>
                                        <h5 class="card-title">
                                            <b> I'm Contact For : <?php echo e($inbox->subject); ?></b>
                                        </h5>
                                        <br>
                                        <div class="card-description">

                                            <?php echo $inbox->details; ?>

                                        </div>
                                        <a href="<?php echo e(route('adminEmail')); ?>" class="btn btn-success" type="button">

                                            Back To Inbox

                                        </a>
                                    </div>
                                </div>
                            </div>

                </div>
            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>