<?php $__env->startSection('title', 'Welcome to CronLab PTC'); ?>

<?php $__env->startSection('content'); ?>

    <body class="section-white">
<div class="cd-section" id="headers">
    <div class="header-3">
        <nav class="navbar navbar-info navbar-transparent navbar-fixed-top navbar-color-on-scroll">
        <?php echo $__env->make('includes.public.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </nav>
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
            <div class="carousel slide" data-ride="carousel">

                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                </ol>

                <!-- Wrapper for slides -->

            <?php echo $__env->make('includes.public.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <!-- Controls -->
                <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                    <i class="material-icons">keyboard_arrow_left</i>
                </a>
                <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                    <i class="material-icons">keyboard_arrow_right</i>
                </a>
            </div>
        </div>



    </div>

    <!--     *********    END HEADER 3      *********      -->
</div>



<div class="cd-section" id="features">

    <div class="container">

        <!--     *********     FEATURES 1      *********      -->

        <?php echo $__env->make('includes.public.features', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!--     *********    END FEATURES 1      *********      -->
    </div>
</div>

<div class="cd-section" id="pricing">
    <!--     *********    PRICING 3     *********      -->

    <div class="pricing-3 section-image" style="background-image: url('<?php echo e(asset('img/city.jpg')); ?>');" id="pricing-3">

        <?php echo $__env->make('includes.public.price', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>

    <!--     *********    END PRICING 3      *********      -->
</div>

<div class="cd-section" id="projects">
    <!--     *********    PROJECTS 4     *********      -->

    <div class="projects-4" id="projects-4">


<?php echo $__env->make('includes.public.source', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    </div>

    <!--     *********    END PROJECTS 4      *********      -->

</div>


<div class="cd-section" id="testimonials">

    <!--     *********    TESTIMONIALS 1     *********      -->

    <div class="testimonials-1 section-image" style="background-image: url('<?php echo e(asset('img/dg2.jpg')); ?>')">


        <?php echo $__env->make('includes.public.testimonals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    </div>

    <!--     *********    END TESTIMONIALS 1      *********      -->

</div>


<footer class="footer">


    <?php echo $__env->make('includes.public.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</footer>

    <?php if($settings->live_chat == 1): ?>

        <?php echo $__env->make('includes.chat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>


    </body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>