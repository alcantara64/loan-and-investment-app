<?php $__env->startSection('title', 'My Withdraw History'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="green">
                    <i class="material-icons">payment</i>
                </div>
                <br>
                <h4 class="card-title">My Withdraw History</h4>
                <div class="card-content">
                    <br>
                    <?php if(count($withdraws) > 0): ?>
                    <div class="table-responsive">

                        <table class="table">
                            <thead>
                            <tr>
                                <th class="text-center">SN</th>
                                <th class="text-center">Transaction Id</th>
                                <th class="text-center">Gateway Name</th>
                                <th class="text-center">Account</th>
                                <th class="text-center">Amount</th>
                                <th class="text-center">Charge</th>
                                <th class="text-center">Funded Amount</th>
                                <th class="text-center">Time</th>
                                <th class="text-center">Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $id=0;?>
                                <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $id++;?>
                            <tr>
                                <td class="text-center"><?php echo e($id); ?></td>
                                <td class="text-center"><?php echo e($withdraw->transaction_id); ?></td>
                                <td class="text-center"><?php echo e($withdraw->gateway_name); ?></td>
                                <td class="text-center"><?php echo e($withdraw->account); ?></td>
                                <td class="text-center">$ <?php echo e($withdraw->amount +0); ?></td>
                                <td class="text-center">$ <?php echo e($withdraw->charge+0); ?></td>
                                <td class="text-center">$ <?php echo e($withdraw->net_amount+0); ?></td>
                                <?php if($withdraw->status == 1): ?>
                                    <td class="text-center"><?php echo e($withdraw->updated_at->diffForHumans()); ?></td>
                                <?php else: ?>
                                    <td class="text-center"><?php echo e($withdraw->created_at->diffForHumans()); ?></td>
                                <?php endif; ?>
                                <td >

                                    <?php if($withdraw->status == 1): ?>

                                        <button class="btn btn-success">
                                        <span class="btn-label">
                                            <i class="material-icons">check</i>
                                        </span>
                                            Completed
                                        </button>


                                    <?php else: ?>

                                        <button class="btn btn-warning">
                                        <span class="btn-label">
                                            <i class="material-icons">warning</i>
                                        </span>
                                            Pending
                                        </button>



                                    <?php endif; ?>



                                </td>
                            </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>

                        <h1 class="text-center">No Withdraw Request</h1>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-5">

                            <?php echo e($withdraws->render()); ?>


                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>


    <?php if(config('app.chat')): ?>

        <?php echo $__env->make('includes.chat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php else: ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>