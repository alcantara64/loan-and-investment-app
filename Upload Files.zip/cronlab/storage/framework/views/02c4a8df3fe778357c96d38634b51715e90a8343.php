
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php echo e(config('app.url')); ?>"><i class="material-icons">home</i> <?php echo e(config('app.name')); ?></a>
        </div>

        <div class="collapse navbar-collapse">

            <ul class="nav navbar-nav navbar-right">

                <?php if(Auth::guest()): ?>
                    <li><a href="<?php echo e(url('/blog')); ?>"> <i class="material-icons">question_answer</i> Latest News</a></li>
                    <li><a href="<?php echo e(url('/contact-us')); ?>"> <i class="material-icons">contact_mail</i> Contact Us</a></li>
                    <li><a href="<?php echo e(route('login')); ?>"> <i class="material-icons">fingerprint</i> Login</a></li>
                    <li><a href="<?php echo e(route('register')); ?>"><i class="material-icons">subscriptions</i> Register</a></li>
                <?php else: ?>
                    <li>
                        <a href="<?php echo e(url('/blog')); ?>">
                            <i class="material-icons">question_answer</i>
                            Latest News
                        </a>
                    </li>
                    <li><a href="<?php echo e(url('/contact-us')); ?>"> <i class="material-icons">contact_mail</i> Contact Us</a></li>
                    <li>
                        <a href="<?php echo e(url('/user/dashboard')); ?>"> <i class="material-icons">dashboard</i> Dashboard </a>
                    </li>
                    <li>
                        <div class="dropdown">
                            <a href="#" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
                                <?php echo e(Auth::user()->name); ?>

                                <b class="caret"></b>
                            </a>
                            <ul class="dropdown-menu">

                                <li>
                                    <a href="<?php echo e(route('userProfile')); ?>"> <i class="material-icons">explicit</i> Edit Profile </a>
                                </li>

                                <li>
                                    <a href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="material-icons">https</i>
                                        Logout
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </li>
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>

            </ul>

        </div>
    </div>
