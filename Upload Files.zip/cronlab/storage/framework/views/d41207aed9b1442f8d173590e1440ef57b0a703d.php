<?php $__env->startSection('title', 'My Referral & Link'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">contacts</i>
                </div>
                <br>
                <h4 class="card-title">My Referral</h4>
                <div class="card-content">
                    <br>
                    <div class="table-responsive">
                        <br>

                            <code class="text-center">
                                <?php echo e($link); ?>

                            </code>
                        <?php if(count($referrals) > 0): ?>
                        <table class="table">
                            <thead>
                            <tr>
                                <th class="text-center">SN</th>
                                <th class="text-center">Photo</th>
                                <th class="text-center">Name</th>
                                <th class="text-center">Membership</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Join Date</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $id=0;?>
                                <?php $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $id++;?>
                                    <tr>
                                        <td class="text-center"><?php echo e($id); ?></td>
                                        <td class="text-center" width="10%" >
                                            <img src="<?php echo e($referral->user->profile->avatar); ?>" class="img-circle" alt="No Photo"  >
                                        </td>
                                        <td class="text-center"><?php echo e($referral->user->name); ?></td>
                                        <td class="text-center"><?php echo e($referral->user->membership->name); ?></td>
                                        <td class="text-center">

                                            <?php if($referral->user->active == 0): ?>
                                                Not Active
                                            <?php else: ?>
                                                Active
                                            <?php endif; ?>

                                        </td>
                                        <td class="text-center"><?php echo e($referral->user->created_at->diffForHumans()); ?></td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>

                            <?php else: ?>
                            <h1> There is no Refer You have made.</h1>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>