<?php $__env->startSection('title', 'View Support Ticket Discussion'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <h4 class="title text-center text-primary">View <b>"<?php echo e($support->ticket); ?>"</b> No. Support Ticket Discussion</h4>
        <h5 class="title text-center text-info">Subject : <b>"<?php echo e($support->subject); ?>"</b></h5>
        <div class="col-md-12">
            <div class="card card-plain">
                <div class="card-content">
                    <ul class="timeline">
                        <li class="timeline-inverted">
                            <div class="timeline-badge">
                                <div class="photo">
                                    <img src="<?php echo e($support->user->profile->avatar); ?>" class="img-circle" />
                                </div>
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <span class="label label-info"><?php echo e($support->user->name); ?> | User</span>
                                </div>
                                <div class="timeline-body">
                                    <p><?php echo Markdown::convertToHtml($support->message); ?></p>
                                </div>
                                <h6>
                                    <i class="ti-time"></i> <?php echo e($support->created_at->diffForHumans()); ?>

                                </h6>
                            </div>
                        </li>

                            <?php $__currentLoopData = $discussions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if($discussion->type == 1): ?>


                        <li>
                            <div class="timeline-badge">
                                <div class="photo">
                                    <img src="<?php echo e($discussion->user->profile->avatar); ?>" class="img-circle" />
                                </div>
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <span class="label label-success"><?php echo e($discussion->user->name); ?> | Support Agent</span>
                                </div>
                                <div class="timeline-body">
                                    <p><?php echo Markdown::convertToHtml($discussion->message); ?></p>
                                </div>
                            </div>
                        </li>

                            <?php elseif($discussion->type == 0): ?>

                                    <li class="timeline-inverted">
                                        <div class="timeline-badge">
                                            <div class="photo">
                                                <img src="<?php echo e($user->profile->avatar); ?>" class="img-circle" />
                                            </div>
                                        </div>
                                        <div class="timeline-panel">
                                            <div class="timeline-heading">
                                                <span class="label label-info"><?php echo e($user->name); ?> | User</span>
                                            </div>
                                            <div class="timeline-body">
                                                <p><?php echo Markdown::convertToHtml($discussion->message); ?></p>
                                            </div>
                                            <h6>
                                                <i class="ti-time"></i> <?php echo e($discussion->created_at->diffForHumans()); ?>

                                            </h6>
                                        </div>
                                    </li>

                                <?php endif; ?>



                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if($support->status > 0): ?>
                        <li class="timeline-inverted">
                            <div class="timeline-badge">
                                <div class="photo">
                                    <img src="<?php echo e($user->profile->avatar); ?>" class="img-circle" />
                                </div>
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <span class="label label-success">Submit Your Message to Support Agent</span>
                                </div>
                                <div class="timeline-body">

                                    <form action="<?php echo e(route('userMessage.post',['ticket'=>$support->ticket])); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-group label-floating">
                                            <label for="message" class="control-label">Message</label>
                                            <textarea name="body" class="form-control" id="message" rows="20"></textarea>
                                        </div>
                                        <a href="<?php echo e(route('userSupports')); ?>" class="btn btn-rose">Cancel Message</a>
                                        <button type="submit" class="btn btn-success pull-right">Submit Message</button>
                                        <div class="clearfix"></div>

                                    </form>



                                </div>
                            </div>
                        </li>
                            <?php endif; ?>



                    </ul>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>