<div class="container-fluid">
    <nav class="pull-left">
        <ul>
            <li>
                <a href="#">
                    Home
                </a>
            </li>
            <li>
                <a href="#">
                    Company
                </a>
            </li>
            <li>
                <a href="#">
                    Portfolio
                </a>
            </li>
            <li>
                <a href="#">
                    Blog
                </a>
            </li>
        </ul>
    </nav>
    <p class="copyright pull-right">
        &copy; By <?php echo e(config('app.name')); ?> <?php echo e(date('Y')); ?>. Developed By <i class="fa fa-heart heart"></i> <a href="<?php echo e(config('app.dev_url')); ?>"><?php echo e(config('app.dev_company')); ?></a>
    </p>
</div>