<?php $__env->startSection('title', 'View All Blog Post'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">contacts</i>
                </div>
                <br>
                <h4 class="card-title">All Blog Post</h4>
                <div class="card-content">
                    <br>

						<?php if(count($posts) > 0): ?>
                    <div class="table-responsive">

                        

                        <table class="table">
                            <thead>
                            <tr>
                                <th class="text-center">ID</th>
                                <th class="text-center">Photo</th>
                                <th class="text-center">Title</th>
                                <th class="text-center">View Post</th>
                                <th class="text-center">Edit Post</th>
                                <th class="text-center">Actions</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $id=0;?>

                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php $id++;?>

                                    <tr>
                                        <td class="text-center"><?php echo e($id); ?></td>
                                        <td width="10%" >
                                            <img src="<?php echo e($post->featured); ?>" class="img-circle" alt="No Photo"  >
                                        </td>

                                        <td><?php echo e(str_limit($post->title, 60)); ?></td>

                                        <td class="td-actions text-center">
                                            <a href="<?php echo e(route('viewPost',['slug'=>$post->slug])); ?>" type="button" rel="tooltip" class="btn btn-info">
                                                <i class="material-icons">edit</i>
                                            </a>
                                        </td>

                                        <td class="td-actions text-center">
                                            <a href="<?php echo e(route('admin.posts.edit',['id'=>$post->id])); ?>" type="button" rel="tooltip" class="btn btn-warning">
                                                <i class="material-icons">edit</i>
                                            </a>
                                        </td>

                                        <td class="td-actions text-center">

                                            <a href="" type="button" rel="tooltip" class="btn btn-danger">
                                                <i class="material-icons">close</i>

                                            </a>

                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>
                        </table>

                    </div>

                    <?php else: ?>

                        <h1 class="text-center">No Blog Post Found</h1>

                    <?php endif; ?>

                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-5">

                            <?php echo e($posts->render()); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>