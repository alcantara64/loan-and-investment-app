<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>

    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('img/apple-icon.png')); ?>" />
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.png')); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title><?php echo e(config('app.dev_name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <!-- Bootstrap core CSS     -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />

    <!--  Material Dashboard CSS    -->
    <link href="<?php echo e(asset('css/material-dashboard.css')); ?>" rel="stylesheet" />
    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo e(asset('css/demo.css')); ?>" rel="stylesheet" />
    <!--     Fonts and icons     -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body>
<div class="wrapper">

    <?php echo $__env->make('includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="main-panel">
        <nav class="navbar navbar-info  navbar-absolute">
            <div class="container-fluid">
                <div class="navbar-minimize">
                    <button id="minimizeSidebar" class="btn btn-round btn-white btn-fill btn-just-icon">
                        <i class="material-icons visible-on-sidebar-regular">more_vert</i>
                        <i class="material-icons visible-on-sidebar-mini">view_list</i>
                    </button>
                </div>
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo e(url('/user/dashboard')); ?>"> Go To User Dashboard </a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                            <li>
                                <div class="dropdown">
                                    <a href="#" class="btn dropdown-toggle" data-toggle="dropdown">
                                        <?php echo e(Auth::user()->name); ?>

                                        <b class="caret"></b>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a href="<?php echo e(route('logout')); ?>"
                                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="material-icons">power_settings_new</i>
                                                Logout
                                            </a>

                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                <?php echo e(csrf_field()); ?>

                                            </form>
                                        </li>
                                    </ul>
                                </div>
                            </li>

                    </ul>
                </div>
            </div>
        </nav>
        <div class="content">
            <div class="container-fluid">



        <?php echo $__env->yieldContent('content'); ?>



            </div>

        </div>

        <footer class="footer">

            <?php echo $__env->make('includes.dfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </footer>

    </div>

</div>

</body>

<!--   Core JS Files   -->
<script src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/material.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/perfect-scrollbar.jquery.min.js')); ?>" type="text/javascript"></script>
<!-- Forms Validations Plugin -->
<script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
<script src="<?php echo e(asset('js/moment.min.js')); ?>"></script>
<!--  Charts Plugin -->
<script src="<?php echo e(asset('js/chartist.min.js')); ?>"></script>
<!--  Plugin for the Wizard -->
<script src="<?php echo e(asset('js/jquery.bootstrap-wizard.js')); ?>"></script>
<!--  Notifications Plugin    -->
<script src="<?php echo e(asset('js/bootstrap-notify.js')); ?>"></script>
<!--   Sharrre Library    -->
<script src="<?php echo e(asset('js/jquery.sharrre.js')); ?>"></script>
<!-- DateTimePicker Plugin -->
<script src="<?php echo e(asset('js/bootstrap-datetimepicker.js')); ?>"></script>
<!-- Vector Map plugin -->
<script src="<?php echo e(asset('js/jquery-jvectormap.js')); ?>"></script>
<!-- Sliders Plugin -->
<script src="<?php echo e(asset('js/nouislider.min.js')); ?>"></script>
<!-- Select Plugin -->
<script src="<?php echo e(asset('js/jquery.select-bootstrap.js')); ?>"></script>
<!--  DataTables.net Plugin    -->
<script src="<?php echo e(asset('js/jquery.datatables.js')); ?>"></script>
<!-- Sweet Alert 2 plugin -->
<script src="<?php echo e(asset('js/sweetalert2.js')); ?>"></script>

<script>
    <?php if(session()->has('message')): ?>
    swal({
        title: "<?php echo session()->get('title'); ?>",
        text: "<?php echo session()->get('message'); ?>",
        type: "<?php echo session()->get('type'); ?>",
        buttonsStyling: false,
        confirmButtonClass: "btn btn-success",
        confirmButtonText: "OK"
    });
    <?php endif; ?>

</script>

<!--	Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
<script src="<?php echo e(asset('js/jasny-bootstrap.min.js')); ?>"></script>
<!--  Full Calendar Plugin    -->
<script src="<?php echo e(asset('js/fullcalendar.min.js')); ?>"></script>
<!-- TagsInput Plugin -->
<script src="<?php echo e(asset('js/jquery.tagsinput.js')); ?>"></script>
<!-- Material Dashboard javascript methods -->
<script src="<?php echo e(asset('js/material-dashboard.js')); ?>"></script>

<!-- Material Dashboard DEMO methods, don't include it in your project! -->
<script src="<?php echo e(asset('js/demo.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function() {

        // Javascript method's body can be found in assets/js/demos.js
        demo.initDashboardPageCharts();

        demo.initVectorMap();
    });

</script>
<?php echo $__env->yieldContent('scripts'); ?>
</html>