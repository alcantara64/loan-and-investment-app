<?php $__env->startSection('title', 'View All User Testimonials'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">contacts</i>
                </div>
                <br>
                <h4 class="card-title">All User Testimonials</h4>
                <div class="card-content">
                    <br>

                    <?php if(count($reviews) > 0): ?>

                    <div class="table-responsive">

                        <table class="table">
                            <thead>
                            <tr>
                                <th class="text-center">ID</th>
                                <th class="text-center">User Email</th>
                                <th class="text-center">Subject</th>
                                <th>Comment</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Action</th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php $id=0;?>
                                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $id++;?>
                                    <tr>
                                        <td class="text-center"><?php echo e($id); ?></td>
                                        <td class="text-center"><?php echo e($review->user->email); ?></td>
                                        <td class="text-center"><?php echo e(str_limit($review->title)); ?></td>
                                        <td><?php echo Markdown::convertToHtml($review->comment); ?></td>
                                        <td class="text-center">

                                            <?php if($review->status == 1): ?>

                                                <span class="btn btn-success" type="button">Published</span>

                                            <?php else: ?>

                                                <span class="btn btn-warning" type="button">Not Published</span>

                                            <?php endif; ?>


                                        </td>

                                        <td class="text-center">

                                            <?php if($review->status == 1): ?>


                                                <a href="<?php echo e(route('adminReview.reject',$review->id)); ?>" type="button" class="btn btn-danger">Un-Publish</a>


                                            <?php else: ?>

                                                <a href="<?php echo e(route('adminReview.accept',$review->id)); ?>" type="button" class="btn btn-success">Publish</a>

                                            <?php endif; ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>
                        </table>

                    </div>
                    <?php else: ?>

                        <h1 class="text-center">No User Testimonials</h1>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-5">

                            <?php echo e($reviews->render()); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>