<?php $__env->startSection('title', 'Latest Promotion Offer, Event & News'); ?>
<?php $__env->startSection('content'); ?>

    <body class="section-white">
    <div class="cd-section" id="headers">
        <div class="header-2">
            <nav class="navbar navbar-info navbar-transparent navbar-fixed-top navbar-color-on-scroll">
                <?php echo $__env->make('includes.public.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </nav>
            <div class="page-header header-filter" style="background-image: url('<?php echo e(asset('img/office2.jpg')); ?>');">
                <div class="container">
                    <div class="row">


                        <?php if(Auth::check()): ?>

                            <div class="col-md-8 col-md-offset-2 text-center">
                                <h1 class="title"> Write A Testimonials For us!</h1>
                                <h4>Are You Working With US? Are You Love This Site? If You do Then Please Write a Testimonials For US. It will help others user to trust our website. Your Testimonials Shows Auto in our Homepage.</h4>
                            </div>
                            <div class="col-md-10 col-md-offset-5">
                                <a href="<?php echo e(url('user/testimonial/create')); ?>" class="btn btn-primary btn-lg">
                                   Write A Review
                                </a>
                            </div>

                        <?php else: ?>


                            <div class="col-md-8 col-md-offset-2 text-center">
                                <h1 class="title"> You should work with us!</h1>
                                <h4>We have many years experience with operating and participating in successful get-paid-to programs; as such, we have a reputation to keep and will go out of our way to keep members happy! That means reliable payments, quick support and excellent website reliability and uptime.</h4>
                            </div>

                            <div class="col-md-10 col-md-offset-5">
                                <a href="<?php echo e(route('register')); ?>" class="btn btn-info btn-lg">
                                    Register Now
                                </a>
                            </div>

                        <?php endif; ?>


                    </div>
                </div>
            </div>

        </div>

        <!--     *********    END HEADER 3      *********      -->
    </div>

    <div class="cd-section" id="blogs">

        <!--     *********     BLOGS 1      *********      -->

        <div class="blogs-1" id="blogs-1">

            <div class="container">
                <div class="row">

                    <div class="col-md-10 col-md-offset-1">
                        <h2 class="title">Latest News and Promotion </h2>

                        <br />

                        <?php if($posts): ?>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="card card-plain card-blog">
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="card-image">
                                        <img class="img img-raised" src="<?php echo e($post->featured ? $post->featured : 'No Photo'); ?>" />
                                    </div>
                                </div>
                                <div class="col-md-7">
                                    <h6 class="category text-primary"><?php echo e($post->category ? $post->category->name : 'Uncategorized'); ?></h6>

                                    <h3 class="card-title">
                                        <a href="<?php echo e(route('viewPost', $post->slug)); ?>"><?php echo e($post->title); ?></a>
                                    </h3>
                                    <p class="author text-info">
                                        by <b><?php echo e($user->name); ?></b>, <?php echo e($post->created_at->diffForHumans()); ?>

                                    </p>
                                    <p class="card-description"><?php echo str_limit($post->content, 500); ?></p>

                                    <a href="<?php echo e(route('viewPost', $post->slug)); ?>" type="button" rel="tooltip" class="btn btn-rose">
                                        <i class="material-icons">edit</i>
                                        Read More
                                    </a>

                                </div>
                            </div>
                        </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endif; ?>


                        <div class="row">
                            <div class="col-sm-6 col-sm-offset-5">

                                <?php echo e($posts->render()); ?>


                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>

        <!--     *********    END BLOGS 1      *********      -->
    </div>


    <footer class="footer">


        <?php echo $__env->make('includes.public.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    </footer>

    <?php if(config('app.chat')): ?>

        <?php echo $__env->make('includes.chat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php else: ?>


    <?php endif; ?>

    </body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>