<?php $__env->startSection('title', 'View All Payment Gateway'); ?>


<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">contacts</i>
                </div>
                <br>
                <h4 class="card-title">All Local Gateways</h4>
                <div class="card-content">
                    <br>

                    <?php if(count($gateways) > 0): ?>

                        <div class="table-responsive">

                            <table class="table">
                                <thead>
                                <tr>
                                    <th class="text-center">ID</th>
                                    <th class="text-center">Name</th>
                                    <th class="text-center">Photo</th>
                                    <th class="text-center">Account No</th>
                                    <th class="text-center">Fixed Fee</th>
                                    <th class="text-center">Percent Fee</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Edit</th>
                                    <th class="text-center">Action</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $id=0;?>
                                <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $id++;?>
                                    <tr>
                                        <td class="text-center"><?php echo e($id); ?></td>
                                        <td class="text-center"><?php echo e($gateway->name); ?></td>
                                        <td width="10%" class="text-center">
                                            <img src="<?php echo e(asset($gateway->image)); ?>" class="img-circle" alt="No Photo">

                                        </td>
                                        <td class="text-center"><?php echo e($gateway->account); ?></td>
                                        <td class="text-center">$ <?php echo e($gateway->fixed); ?></td>
                                        <td class="text-center"><?php echo e($gateway->percent); ?> %</td>
                                        <td class="text-center"><?php echo e($gateway->status == 1 ? 'Active':'Not Active'); ?></td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('admin.local.edit', $gateway->id)); ?>" type="button" class="btn btn-success">
                                                <i class="material-icons">edit</i>

                                            </a>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('admin.local.delete', $gateway->id)); ?>" type="button" class="btn btn-danger">
                                                <i class="material-icons">close</i>

                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>

                        </div>

                    <?php else: ?>

                        <h1 class="text-center">No Local Payment Gateway Found</h1>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>