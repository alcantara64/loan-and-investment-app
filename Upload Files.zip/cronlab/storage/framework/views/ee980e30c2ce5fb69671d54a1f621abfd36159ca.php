<?php $__env->startSection('title', 'Edit Paid To Click Advertisement'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="purple">
                    <i class="material-icons">face</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">Paid To Click Section -
                        <small class="category">Edit PTC Advertisement</small>
                    </h4>
                    <form action="<?php echo e(route('admin.ptc.update', ['id'=>$advertisement->id])); ?>" method="post">
                        <?php echo e(csrf_field()); ?>


                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger alert-with-icon" data-notify="container">
                                <i class="material-icons" data-notify="icon">notifications</i>
                                <span data-notify="message">

                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><strong> <?php echo e($error); ?> </strong></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </span>
                            </div>
                        <?php endif; ?>


                        <div class="row">

                            <div class="col-md-12">
                                <div class="form-group label-floating">

                                    <label  class="control-label" for="title">Title</label>
                                    <input id="title" name="title" type="text" value="<?php echo e($advertisement->title); ?>" class="form-control">

                                </div>
                            </div>
                        </div>

                        <div class="row">

                            <div class="col-md-12">
                                <div class="form-group label-floating">

                                    <label  class="control-label" for="ptc">Website Link</label>
                                    <input id="ptc" name="ad_link" type="url" value="<?php echo e($advertisement->ad_link); ?>" class="form-control">

                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">

                            <div class="col-md-12">

                                <div class="form-group label-floating">
                                    <select class="selectpicker" name="membership_id" data-style="btn btn-warning btn-round" title="Select Membership" data-size="7">
                                        <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <option value="<?php echo e($membership->id); ?>"

                                                    <?php if($advertisement->membership->id == $membership->id): ?>

                                                    selected

                                                    <?php endif; ?>

                                            > <?php echo e($membership->name); ?> </option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                            </div>
                        </div>
                        <br>

                        <div class="row">

                            <div class="col-md-12">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="rewards">Rewards</label>
                                    <input id="rewards" name="rewards" type="text" value="<?php echo e($advertisement->rewards); ?>" class="form-control">

                                </div>
                            </div>
                        </div>

                        <div class="row">

                            <div class="col-md-12">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="duration">Duration (Second)</label>
                                    <input id="duration" name="duration" type="number" value="<?php echo e($advertisement->duration); ?>" class="form-control">

                                </div>
                            </div>
                        </div>

                        <div class="row">

                            <div class="col-md-12">
                                <div class="form-group label-floating">

                                    <label  class="control-label" for="details">Details</label>
                                    <textarea class="form-control" name="details" id="details" rows="10"> <?php echo e($advertisement->details); ?></textarea>

                                </div>
                            </div>
                        </div>

                        <a href="<?php echo e(route('admin.ptcs.index')); ?>" class="btn btn-rose">Cancel Post</a>

                        <button type="submit" class="btn btn-success pull-right">Save Changes</button>

                        <div class="clearfix"></div>

                    </form>

                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>