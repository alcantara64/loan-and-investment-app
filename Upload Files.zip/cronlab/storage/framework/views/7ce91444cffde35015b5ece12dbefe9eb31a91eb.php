<?php $__env->startSection('title', 'Your All Support Request'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">contacts</i>
                </div>
                <br>
                <h4 class="card-title">Your All Support Request</h4>
                <div class="card-content">
                    <br>
                    <br>
                    <?php if(count($supports) > 0): ?>
                        <div class="table-responsive">

                            <table class="table">
                                <thead>
                                <tr>
                                    <th class="text-center">SN</th>
                                    <th class="text-center">Ticket Number</th>
                                    <th class="text-center">Subject</th>
                                    <th class="text-center">View</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Action</th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php $id=0;?>
                                <?php $__currentLoopData = $supports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $support): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $id++;?>
                                    <tr>
                                        <td class="text-center"><?php echo e($id); ?></td>
                                        <td class="text-center"><code><?php echo e($support->ticket); ?></code></td>
                                        <td class="text-center"><?php echo e($support->subject); ?></td>
                                        <td class="text-center">

                                            <a href="<?php echo e(route('userSupport.view', $support->ticket)); ?>" type="button" class="btn btn-info">
                                                <i class="material-icons">search</i> View
                                            </a>


                                        </td>
                                        <td class="text-center">

                                            <?php if($support->status == 1): ?>
                                                <button class="btn btn-success">
                                                        <span class="btn-label">
                                                            <i class="material-icons">check</i>
                                                        </span>
                                                    Open
                                                </button>

                                            <?php elseif($support->status == 2): ?>
                                                <button class="btn btn-info">
                                                        <span class="btn-label">
                                                            <i class="material-icons">check</i>
                                                        </span>
                                                    Agent Answered
                                                </button>
                                            <?php elseif($support->status == 3): ?>
                                                <button class="btn btn-success">
                                                        <span class="btn-label">
                                                            <i class="material-icons">check</i>
                                                        </span>
                                                    You Answered
                                                </button>
                                            <?php elseif($support->status == 0): ?>
                                                <button class="btn btn-danger">
                                                        <span class="btn-label">
                                                            <i class="material-icons">close</i>
                                                        </span>
                                                    Close
                                                </button>

                                            <?php endif; ?>

                                        </td>

                                        <td class="text-center">
                                            <?php if($support->status > 0): ?>
                                            <a href="<?php echo e(route('userSupport.close', $support->id)); ?>" type="button" class="btn btn-danger">
                                                <i class="material-icons">close</i> Close
                                            </a>

                                            <?php else: ?>
                                                <span type="button" class="btn btn-danger" disabled><i class="material-icons">close</i> Close</span>

                                            <?php endif; ?>


                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>

                    <?php else: ?>

                        <h1 class="text-center">No Support Request</h1>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-5">

                            <?php echo e($supports->render()); ?>


                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>