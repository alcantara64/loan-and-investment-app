<?php $__env->startSection('title', 'Page'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">contacts</i>
                </div>
                <br>
                <h4 class="card-title">All Website Page</h4>
                <div class="card-content">
                    <br>

                    <?php if(count($pages) > 0): ?>
                        <div class="table-responsive">



                            <table class="table">
                                <thead>
                                <tr>
                                    <th class="text-center">ID</th>
                                    <th class="text-center">Title</th>
                                    <th class="text-center">View Page</th>
                                    <th class="text-center">Edit Post</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php $id=0;?>

                                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php $id++;?>

                                    <tr>
                                        <td class="text-center"><?php echo e($id); ?></td>

                                        <td><?php echo e(str_limit($page->title, 60)); ?></td>

                                        <td class="td-actions text-center">
                                            <a href="<?php echo e(route('viewPage',['slug'=>$page->slug])); ?>" type="button" rel="tooltip" class="btn btn-info">
                                                <i class="material-icons">search</i>
                                            </a>
                                        </td>

                                        <td class="td-actions text-center">
                                            <a href="<?php echo e(route('adminPage.edit',['id'=>$page->id])); ?>" type="button" rel="tooltip" class="btn btn-primary">
                                                <i class="material-icons">edit</i>
                                            </a>
                                        </td>

                                        <td class="text-center">

                                            <?php if($page->status == 1): ?>
                                                <span type="button" class="btn btn-success"> Already Published </span>
                                             <?php else: ?>
                                                <span type="button" class="btn btn-danger"> Not Published </span>
                                             <?php endif; ?>

                                        </td>

                                        <td class="text-center">
                                            <?php if($page->status == 1): ?>
                                            <a href="<?php echo e(route('adminPage.unPublish',['id'=>$page->id])); ?>" type="button" rel="tooltip" class="btn btn-danger">
                                                Un-Publish
                                            </a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('adminPage.Publish',['id'=>$page->id])); ?>" type="button" rel="tooltip" class="btn btn-rose">
                                                    Publish
                                                </a>
                                            <?php endif; ?>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>

                        </div>

                    <?php else: ?>

                        <h1 class="text-center">No Website Page Found</h1>

                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>