<?php $__env->startSection('title', 'All Latest Withdrawals Request'); ?>

<?php $__env->startSection('content'); ?>


    <body class="section-white">
    <div class="cd-section" id="headers">
        <div class="header-1">
            <nav class="navbar navbar-info navbar-transparent navbar-fixed-top navbar-color-on-scroll">
                <?php echo $__env->make('includes.public.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </nav>
            <div class="page-header header-filter" style="background-image: url('<?php echo e(asset('img/bg12.jpg')); ?>');">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <h1 class="title">Get Paid to Surf</h1>
                            <h4>Are you ready to start making money online with little effort? We are an ideal get-paid-to website that you can trust. We have been around for a while and we actually pay! Don't waste your time with scam sites, join CronLab PTC today and start earning real cash now!</h4>
                            <br />

                            <?php if(Auth::check()): ?>

                                <a href="#" target="_blank" class="btn btn-success btn-lg">
                                    <i class="fa fa-ticket"></i> View Ads Now
                                </a>

                            <?php else: ?>


                                <a href="<?php echo e(url('/register')); ?>" target="_self" class="btn btn-primary btn-lg">
                                    <i class="fa fa-ticket"></i> Join Now
                                </a>


                            <?php endif; ?>

                        </div>

                        <?php if(env('BLOG_YOUTUBE_EMBED_CODE')): ?>

                            <div class="col-md-5 col-md-offset-1">
                                <div class="iframe-container">
                                    <iframe src="https://www.youtube.com/embed/<?php echo e(env('BLOG_YOUTUBE_EMBED_CODE')); ?>?modestbranding=1&amp;autohide=1&amp;showinfo=0" frameborder="0" allowfullscreen height="250"></iframe>
                                </div>
                            </div>

                        <?php else: ?>


                        <?php endif; ?>


                    </div>
                </div>
            </div>

        </div>

        <!--     *********    END HEADER 3      *********      -->
    </div>

    <div class="main main-raised">
        <div class="container">
            <div class="section section-text">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <!-- Tabs with icons on Card -->
                        <div class="card card-nav-tabs">
                            <div class="header header-rose">
                                <!-- colors: "header-primary", "header-info", "header-success", "header-warning", "header-danger" -->
                                <div class="nav-tabs-navigation">
                                    <div class="nav-tabs-wrapper">
                                        <ul class="pull-center nav nav-tabs" data-tabs="tabs">
                                            <li class="active">
                                                <a href="#deposit" data-toggle="tab">
                                                    <i class="material-icons">face</i>
                                                    Latest Withdraws
                                                </a>
                                            </li>


                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="card-content">
                                <div class="tab-content text-center">
                                    <div class="tab-pane active" id="deposit">

                                        <?php if(count($withdraws) > 0): ?>
                                            <div class="table-responsive">

                                                <table class="table">
                                                    <thead>
                                                    <tr>
                                                        <th class="text-center">SN</th>
                                                        <th class="text-center">Gateway</th>
                                                        <th class="text-center">Name</th>
                                                        <th class="text-center">Amount</th>
                                                        <th class="text-center">Time</th>
                                                        <th class="text-center">Status</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php $id=0;?>
                                                    <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $id++;?>
                                                        <tr>
                                                            <td class="text-center"><?php echo e($id); ?></td>
                                                            <td class="text-center"><?php echo e($withdraw->gateway_name); ?></td>
                                                            <td class="text-center"><?php echo e($withdraw->user->name); ?></td>
                                                            <td class="text-center"><?php echo e(config('app.currency_symbol')); ?> <?php echo e($withdraw->amount); ?></td>
                                                            <td class="text-center"><?php echo e($withdraw->updated_at->diffForHumans()); ?></td>

                                                            <td class="actions text-center">
                                                                <?php if($withdraw->status == 1): ?>
                                                                    <button class="btn btn-success btn-sm">
                                        <span class="btn-label">
                                            <i class="material-icons">check</i>
                                        </span>
                                                                        Ok
                                                                    </button>
                                                                <?php else: ?>

                                                                    <button class="btn btn-warning btn-sm">
                                        <span class="btn-label">
                                            <i class="material-icons">warning</i>
                                        </span>
                                                                        Pending
                                                                    </button>



                                                                <?php endif; ?>






                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </tbody>
                                                </table>
                                            </div>

                                        <?php else: ?>

                                            <h1 class="text-center">No Withdraw Request</h1>
                                        <?php endif; ?>



                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- End Tabs with icons on Card -->
                    </div>
                </div>
            </div>



        </div>
    </div>


    <footer class="footer">


        <?php echo $__env->make('includes.public.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    </footer>

    </body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>