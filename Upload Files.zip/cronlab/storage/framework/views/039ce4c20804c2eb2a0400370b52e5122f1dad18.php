<?php $__env->startSection('title', 'All Blog Categories'); ?>


<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-md-7">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">contacts</i>
                </div>
                <br>
                <h4 class="card-title">All Blog Categories</h4>
                <div class="card-content">
                    <br>


                    <div class="table-responsive">

                        <table class="table">
                            <thead>
                            <tr>
                                <th class="text-center">ID</th>
                                <th>Name</th>
                                <th>Created</th>
                                <th>Updated</th>
                                <th class="text-right">Actions</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php if($categories): ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td class="text-center"><?php echo e($category->id); ?></td>
                                        <td><?php echo e($category->name); ?></td>
                                        <td><?php echo e($category->created_at->diffForHumans()); ?></td>
                                        <td><?php echo e($category->updated_at->diffForHumans()); ?></td>
                                        <td class="td-actions text-right">

                                            <a href="<?php echo e(route('admin.category.edit', $category->id)); ?>" type="button" rel="tooltip" class="btn btn-success">
                                                <i class="material-icons">edit</i>
                                            </a>

                                            <a href="<?php echo e(route('admin.category.delete', $category->id)); ?>" type="button" rel="tooltip" class="btn btn-danger">
                                                <i class="material-icons">close</i>
                                            </a>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-5">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">contacts</i>
                </div>
                <br>
                <h4 class="card-title">Create Categories</h4>
                <div class="card-content">
                    <br>

                    <form class="m-form" action="<?php echo e(route('admin.category.store')); ?>" method="post">

                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger alert-with-icon" data-notify="container">
                                <i class="material-icons" data-notify="icon">notifications</i>
                                <span data-notify="message">

                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><strong> <?php echo e($error); ?> </strong></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </span>
                            </div>
                        <?php endif; ?>
                    <div class="row">

                        <div class="col-md-12">

                            <div class="form-group">
                                <div class="form-group label-floating">

                                        <label  class="control-label" for="name">Full Name</label>
                                        <input id="name" name="name" type="text" class="form-control">

                                </div>

                            </div>

                        </div>
                    </div>
                    <br>

                        <button type="submit" class="btn btn-success pull-right">Create Category</button>

                    <div class="clearfix"></div>
                    </form>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>