<?php $__env->startSection('title', 'Cash in balance to your account'); ?>
<?php $__env->startSection('content'); ?>


        <div class="row">

            <div class="col-md-8 col-md-offset-2">
                <div class="card card-content">
                    <div class="card-content">
                        <div class="alert alert-info">
                                <span> You have been select <b><?php echo e($gateway->name); ?></b>. Please note that <b><?php echo e($gateway->name); ?></b> will be charge you <b>$<?php echo e($gateway->fixed); ?></b> fixed + <b><?php echo e($gateway->percent); ?>%</b> fee in every deposit.</span>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <h4><span class="text-primary">Current Balance: </span><span class="text-danger"><b>$<?php echo e($user->profile->deposit_balance +0); ?></b></span></h4>
                                <h4><span class="text-primary">Your  Amount: </span><span class="text-danger"><b>$<?php echo e($deposit->amount +0); ?></b></span></h4>
                                <h4><span class="text-primary">Gateway Charge: </span><span class="text-danger"><b>$<?php echo e($deposit->charge + 0); ?></b></span></h4>
                                <h4><span class="text-primary">Amount + Charge: </span><span class="text-danger"><b>$<?php echo e(($deposit-> net_amount + $deposit->charge) + 0); ?></b></span></h4>
                            </div>
                            <div class="col-md-6">
                                <br><br>
                                <h3><span class="text-primary">Reference Code: </span><span class="text-danger"><b><?php echo e($deposit->code); ?></b></span></h3>

                            </div>
                        </div>
                        <div class="alert alert-primary">
                            <span> You want to deposit your money via <b><?php echo e($gateway->name); ?></b>? Read The Instructions Carefully Below And Follow That. It can take lot of time to verify your deposit if you do Mistake.  </span>
                        </div>

                        <div class="row">
                            <div class="col-md-8 col-md-offset-2">
                                <h4 class="text-center text-success">Gateway Name: <b><?php echo e($gateway->name); ?></b> </h4>
                                <h4 class="text-center text-success">Our Account Number: <b><?php echo e($gateway->account); ?></b> </h4>
                                <?php if($gateway->details): ?>

                                    <div class="text-center">

                                        <?php echo Markdown::convertToHtml($gateway->details); ?>


                                    </div>

                                <?php endif; ?>
                            </div>
                        </div>
                        <br> <br>
                        <div class="row">
                            <div class="col-md-12">
                                <h5 class="text-info">Step 1: Go to your <b><?php echo e($gateway->name); ?></b> Account.</h5>
                                <h5 class="text-info">Step 2: Write This "<b><?php echo e($deposit->code); ?></b>" to Reference Option &amp; Send $60 to Our <b><?php echo e($gateway->name); ?></b> Account That Provided Above.</h5>
                                <h5 class="text-info">Step 3: After Successfully Payment Click "Confirm Deposit" Button for confirm deposit.</h5>
                                    <br>
                                <h5 class="text-center text-danger">Note: Please don't send money without this "<b><?php echo e($deposit->code); ?></b>" Reference code . Otherwise we can't verify your payment.
                                    Then it can be long time to process your deposit. <b>And Remember if you didn't send money us then don't click "Confirm Button" below otherwise you can be banned for Spamming</b>. Thanks for working with us</h5>
                            </div>
                        </div>
                        <div class="row">
                            <form action="<?php echo e(route('userDepConfirm')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="gateway" value="<?php echo e($gateway->id); ?>" />
                                <input type="hidden" name="reference" value="<?php echo e($deposit->code); ?>" />
                                <input type="hidden" name="amount" value="<?php echo e($deposit->amount); ?>" />

                                <div class="form-group">
                                    <div class="col-sm-6 col-sm-offset-4">
                                        <button class="btn btn-success"><i
                                                    class="fa fa-send"></i> Confirm Now</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>


        </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>