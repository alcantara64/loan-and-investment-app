<?php $__env->startSection('title', 'My Investments Interest History'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="green">
                    <i class="material-icons">payment</i>
                </div>
                <br>
                <h4 class="card-title">My Investments Interest History</h4>
                <div class="card-content">
                    <br>
                    <?php if(count($logs) > 0): ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th class="text-center">SN</th>
                                    <th class="text-center">Reference Id</th>
                                    <th class="text-center">Invest Type</th>
                                    <th class="text-center">Interest Rate</th>
                                    <th class="text-center">Amount</th>
                                    <th class="text-center">Process Time</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $id=0;?>
                                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $id++;?>
                                    <tr>
                                        <td class="text-center"><?php echo e($id); ?></td>
                                        <td class="text-center"><?php echo e($log->reference_id); ?></td>
                                        <td class="text-center"><?php echo e($log->invest->plan->style->name); ?></td>
                                        <td class="text-center"><?php echo e($log->invest->plan->percentage +0); ?>%</td>
                                         <td class="text-center"><?php echo e(config('app.currency_symbol')); ?> <?php echo e($log->amount + 0); ?></td>
                                        <td class="text-center"><?php echo e($log->created_at->diffForHumans()); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>

                    <?php else: ?>

                        <h1 class="text-center">No Don't Have any Investment Yet</h1>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-5">

                            <?php echo e($logs->render()); ?>


                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>