<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('img/apple-icon.png')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.png')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />

    <!-- CSS Files -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/material-kit.min3f71.css?v=1.1.1')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('css/material-dashboard.css')); ?>" rel="stylesheet" />
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

</head>
<body class="login-page">

<div class="cd-section" id="headers">
    <div class="header-3">
        <nav class="navbar navbar-primary navbar-transparent navbar-absolute">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name')); ?></a>
                </div>

                <div class="collapse navbar-collapse">

                        <ul class="nav navbar-nav navbar-right">

                            <?php if(Auth::guest()): ?>
                                <li><a href="<?php echo e(url('/blog')); ?>"> <i class="material-icons">question_answer</i> Blog</a></li>
                                <li><a href="<?php echo e(url('/contact-us')); ?>"> <i class="material-icons">contact_mail</i> Contact Us</a></li>
                                <li><a href="<?php echo e(route('login')); ?>"> <i class="material-icons">fingerprint</i> Login</a></li>
                                <li><a href="<?php echo e(route('register')); ?>"><i class="material-icons">subscriptions</i> Register</a></li>
                            <?php else: ?>
                                <li>
                                    <a href="<?php echo e(url('/blog')); ?>">
                                        <i class="material-icons">question_answer</i>
                                        Blog
                                    </a>
                                </li>

                                <li><a href="<?php echo e(url('/contact-us')); ?>"> <i class="material-icons">contact_mail</i> Contact Us</a></li>
                                <li>
                                    <a href="<?php echo e(url('/user/dashboard')); ?>"> <i class="material-icons">dashboard</i> Dashboard </a>
                                </li>
                                <li>
                                    <div class="dropdown">
                                        <a href="#" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
                                            <?php echo e(Auth::user()->name); ?>

                                            <b class="caret"></b>
                                        </a>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <a href="<?php echo e(route('subscriber.runsetup', Auth::user()->id)); ?>"> <i class="material-icons">recent_actors</i> My Profile </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('subscriber.runsetup', Auth::user()->id)); ?>"> <i class="material-icons">explicit</i> Edit Profile </a>
                                            </li>
                                            <li>
                                                <a href="#"> <i class="material-icons">usb</i> Settings </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('logout')); ?>"
                                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="material-icons">https</i>
                                                    Logout
                                                </a>

                                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                    <?php echo e(csrf_field()); ?>

                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                            <?php endif; ?>
                        </ul>

                </div>
            </div>
        </nav>

    </div>

</div>

<div class="page-header header-filter" style="background-image: url('<?php echo e(asset('img/bg7.jpg')); ?>'); background-size: cover; background-position: top center;">
        <?php echo $__env->yieldContent('content'); ?>




<footer class="footer">
    <?php echo $__env->make('includes.public.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</footer>
</div>
</body>

<!--   Core JS Files   -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/material.min.js')); ?>"></script>


<!--	Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/   -->
<script src="<?php echo e(asset('js/nouislider.min.js')); ?>" type="text/javascript"></script>

<!--    Plugin for Date Time Picker and Full Calendar Plugin   -->
<script src="<?php echo e(asset('js/moment.min.js')); ?>"></script>

<!--	Plugin for the Datepicker, full documentation here: https://github.com/Eonasdan/bootstrap-datetimepicker   -->
<script src="<?php echo e(asset('js/bootstrap-datetimepicker.js')); ?>" type="text/javascript"></script>

<!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select   -->
<script src="<?php echo e(asset('js/bootstrap-selectpicker.js')); ?>" type="text/javascript"></script>

<!--	Plugin for Tags, full documentation here: http://xoxco.com/projects/code/tagsinput/   -->
<script src="<?php echo e(asset('js/bootstrap-tagsinput.js')); ?>"></script>

<!--	Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput   -->
<script src="<?php echo e(asset('js/jasny-bootstrap.min.js')); ?>"></script>
<!--    Plugin for 3D images animation effect, full documentation here: https://github.com/drewwilson/atvImg    -->
<script src="<?php echo e(asset('js/atv-img-animation.js')); ?>" type="text/javascript"></script>

<!--    Control Center for Material Kit: activating the ripples, parallax effects, scripts from the example pages etc    -->
<script src="<?php echo e(asset('js/material-kit.min3f71.js?v=1.1.1')); ?>" type="text/javascript"></script>

</html>