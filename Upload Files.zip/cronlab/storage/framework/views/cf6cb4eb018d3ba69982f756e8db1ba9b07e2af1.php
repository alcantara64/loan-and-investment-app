<?php $__env->startSection('title', 'Edit Invest Plan'); ?>

<?php $__env->startSection('styles'); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-9 col-md-offset-1">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="purple">
                    <i class="material-icons">face</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">Invest Plan Section -
                        <small class="category">Edit Invest Plan</small>
                    </h4>
                    <form action="<?php echo e(route('adminInvest.update',['id'=>$plan->id])); ?>" method="post" enctype="multipart/form-data">

                        <?php echo e(csrf_field()); ?>


                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger alert-with-icon" data-notify="container">
                                <i class="material-icons" data-notify="icon">notifications</i>
                                <span data-notify="message">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><strong> <?php echo e($error); ?> </strong></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </span>
                            </div>
                        <?php endif; ?>


                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="name">Invest Plan Name</label>
                                    <input id="name" name="name" type="text" value="<?php echo e($plan->name); ?>" class="form-control">

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">

                                <div class="form-group label-floating">
                                    <p class="text-info">Select Invest Style</p>
                                    <select class="selectpicker" name="style_id" data-style="btn btn-warning btn-round" title="Select Category" data-size="7">
                                        <?php $__currentLoopData = $styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($style->id); ?>"
                                                    <?php if($plan->style->id == $style->id): ?>
                                                    selected
                                                    <?php endif; ?>
                                            > <?php echo e($style->name); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="minimum">Minimum Invest (in <?php echo e(config('app.currency_code')); ?>)</label>
                                    <input id="minimum" name="minimum" type="number" value="<?php echo e($plan->minimum +0); ?>" class="form-control">
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="maximum">Maximum Invest (in <?php echo e(config('app.currency_code')); ?>)</label>
                                    <input id="maximum" name="maximum" type="number" value="<?php echo e($plan->maximum +0); ?>" class="form-control">
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="percentage">Invest Interest Return (in Percentage)</label>
                                    <input id="percentage" name="percentage" type="text" value="<?php echo e($plan->percentage); ?>" class="form-control">
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="repeat">Total Repeat (Interest Return Frequency)</label>
                                    <input id="repeat" name="repeat" type="number" value="<?php echo e($plan->repeat); ?>" class="form-control">
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="start_duration">Invest Start Delay (in Hour)</label>
                                    <input id="start_duration" name="start_duration" type="number" value="<?php echo e($plan->start_duration); ?>" class="form-control">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <p class="text-info">Select Plan Status</p>
                                <div class="form-group label-floating">
                                    <select class="selectpicker" name="status" data-style="btn btn-warning btn-round" title="Select Category" data-size="7">
                                        <option value="0"
                                                <?php if($plan->status == 0): ?>
                                                selected
                                                <?php endif; ?>
                                        >Not Active</option>

                                        <option value="1"
                                                <?php if($plan->status == 1): ?>
                                                selected
                                                <?php endif; ?>
                                        >Active</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <br> <br>

                        <a href="<?php echo e(route('adminInvest')); ?>" class="btn btn-rose">Cancel Edit</a>

                        <button type="submit" class="btn btn-success pull-right">Update Plan</button>

                        <div class="clearfix"></div>
                    </form>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>