<?php $__env->startSection('title', 'Pick the best plan for you'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3 text-center">
                        <h2 class="title">Pick the best plan for you</h2>
                        <h5 class="description">Bigger package has Bigger Earning System and Premium Support on each package.</h5>
                    </div>
                </div>


                <div class="card-content">
                    <br>
                    <?php if($memberships): ?>
                        <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-md-3">
                                <div class="card card-pricing card-raised">
                                    <div class="card-content">
                                        <h6 class="category"><?php echo e($membership->name); ?></h6>
                                        <div class="icon icon-info">
                                            <i class="material-icons">highlight</i>
                                        </div>
                                        <h3 class="card-title">

                                            <?php if($membership->price == 0): ?>

                                                Free

                                            <?php else: ?>
                                                <?php echo e(config('app.currency_symbol')); ?> <?php echo e($membership->price + 0); ?>

                                            <?php endif; ?>


                                        </h3>
                                        <p class="card-description">
                                            <?php echo $membership->details; ?>

                                        </p>

                                        <?php if($membership->id == $user->membership_id): ?>

                                            <span class="btn btn-warning">Already Upgraded</span>

                                        <?php else: ?>
                                            <a href="<?php echo e(route('userMembership.upgrade', $membership->id)); ?>" type="button" rel="tooltip" class="btn btn-primary">
                                                Upgraded Now
                                            </a>

                                        <?php endif; ?>


                                    </div>
                                </div>
                            </div>



                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>