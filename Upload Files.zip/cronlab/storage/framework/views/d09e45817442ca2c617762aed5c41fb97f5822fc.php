<?php $__env->startSection('title', 'All User Deposit Request'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">contacts</i>
                </div>
                <br>
                <h4 class="card-title">Deposit Request</h4>
                <div class="card-content">
                    <br>
                    <br>
                    <?php if(count($deposits) > 0): ?>
                        <div class="table-responsive">

                            <table class="table">
                                <thead>
                                <tr>
                                    <th class="text-center">SN</th>
                                    <th class="text-center">Transaction Id</th>
                                    <th class="text-center">Gateway</th>
                                    <th class="text-center">Amount</th>
                                    <th class="text-center">Charge</th>
                                    <th class="text-center">Funded</th>
                                    <th class="text-center">Time</th>
                                    <th class="text-center">Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $id=0;?>
                                <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $id++;?>
                                    <tr>
                                        <td class="text-center"><?php echo e($id); ?></td>
                                        <td class="text-center"><?php echo e($deposit->transaction_id); ?></td>
                                        <td class="text-center"><?php echo e($deposit->gateway_name); ?></td>
                                        <td class="text-center"><?php echo e(config('app.currency_symbol')); ?> <?php echo e($deposit->amount); ?></td>
                                        <td class="text-center"><?php echo e(config('app.currency_symbol')); ?> <?php echo e($deposit->charge); ?></td>
                                        <td class="text-center"><?php echo e(config('app.currency_symbol')); ?> <?php echo e($deposit->net_amount); ?></td>
                                        <td class="text-center"><?php echo e($deposit->created_at->diffForHumans()); ?></td>

                                        <td class="text-center">

                                            <?php if($deposit->status == 1): ?>

                                                <button class="btn btn-success">
                                        <span class="btn-label">
                                            <i class="material-icons">check</i>
                                        </span>
                                                    Completed
                                                </button>


                                            <?php else: ?>

                                                <button class="btn btn-warning">
                                        <span class="btn-label">
                                            <i class="material-icons">warning</i>
                                        </span>
                                                    Pending
                                                </button>



                                            <?php endif; ?>



                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>

                    <?php else: ?>

                        <h1 class="text-center">No Deposit Request</h1>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-5">

                            <?php echo e($deposits->render()); ?>


                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>