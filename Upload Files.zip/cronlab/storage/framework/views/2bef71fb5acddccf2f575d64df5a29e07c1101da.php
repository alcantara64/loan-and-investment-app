<?php $__env->startSection('title', 'Edit Member Profile'); ?>

<?php $__env->startSection('content'); ?>


    <div class="row">

        <div class="col-md-8">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="purple">
                    <i class="material-icons">perm_identity</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">My Profile -
                        <small class="category">Edit Your profile</small>
                    </h4>

                    <form action="<?php echo e(route('userProfile.update')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger alert-with-icon" data-notify="container">
                                <i class="material-icons" data-notify="icon">notifications</i>
                                <span data-notify="message">

                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><strong> <?php echo e($error); ?> </strong></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </span>
                            </div>
                        <?php endif; ?>

                        <div class="row">
                            <div class="col-md-6 col-md-offset-3">
                                <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                    <div class="fileinput-new thumbnail">
                                        <img src="<?php echo e(asset($user->profile->avatar)); ?>" alt="...">
                                    </div>
                                    <div class="fileinput-preview fileinput-exists thumbnail"></div>
                                    <div>
                                                    <span class="btn btn-rose btn-round btn-file">
                                                        <span class="fileinput-new">Select image</span>
                                                        <span class="fileinput-exists">Change</span>
                                                        <input type="file" name="avatar" />
                                                    </span>
                                        <a href="#" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">

                            <div class="col-md-6">

                                <div class="form-group label-floating">

                                    <label  class="control-label" for="name">Full Name</label>
                                    <input id="name" name="name" type="text" value="<?php echo e($user->name); ?>" class="form-control">

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="email">Email Address</label>
                                    <input id="email" name="email" value="<?php echo e($user->email); ?>" type="text" class="form-control">
                                </div>
                            </div>

                        </div>
                        <div class="row">

                            <div class="col-md-6">

                                <div class="form-group label-floating">
                                    <label  class="control-label" for="occupation">Occupation</label>
                                    <input id="occupation" name="occupation" type="text" value="<?php echo e($user->profile->occupation); ?>" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="mobile">Mobile Number</label>
                                    <input id="mobile" name="mobile" type="text" value="<?php echo e($user->profile->mobile); ?>" class="form-control">
                                </div>
                            </div>

                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="address">Address Line 1</label>
                                    <input id="address" name="address" value="<?php echo e($user->profile->address); ?>"  type="text" class="form-control">

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="address2">Address Line 2</label>
                                    <input id="address2" name="address2" value="<?php echo e($user->profile->address2); ?>" type="text" class="form-control">

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="city">City</label>
                                    <input id="city" name="city" type="text" value="<?php echo e($user->profile->city); ?>" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="state">State</label>
                                    <input id="state" name="state" type="text" value="<?php echo e($user->profile->state); ?>" class="form-control">
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="postcode">Postal Code</label>
                                    <input id="postcode" name="postcode" type="text" value="<?php echo e($user->profile->postcode); ?>" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-md-4">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="country">Member Country</label>
                                    <input id="country" name="country" type="text" value="<?php echo e($user->profile->country); ?>" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="facebookurl">Facebook Profile Url</label>
                                    <input id="facebookurl" name="facebook" type="text" value="<?php echo e($user->profile->facebook); ?>" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="form-group label-floating">
                                        <label  class="control-label" for="about">About</label>
                                        <input id="about" name="about" type="text" value="<?php echo e($user->profile->about); ?>" class="form-control">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(route('userDashboard')); ?>" class="btn btn-rose">Cancel Edit</a>
                        <button type="submit" class="btn btn-success pull-right">Update Profile</button>
                        <div class="clearfix"></div>
                    </form>
                </div>
            </div>
        </div>

        <div class="row">

            <div class="col-md-4">
                <div class="card card-content">
                    <div class="card-content">
                        <div class="alert alert-primary">
                            <h4 class="card-title text-center"><span>KYC Verify Status</span></h4>
                        </div>
                        <br>
                        <?php if(count($identity) == 0 and count($address) == 0): ?>
                        <h5 class="card-title"><span class="text-danger">Identity Verify:   </span> <span class="btn btn-info btn-sm">Not Yet Submit</span></h5>
                        <br>
                        <h5 class="card-title"><span class="text-danger">Address Verify:    </span><span class="btn btn-info btn-sm">Not Yet Submit</span></h5>
                        <br>
                        <a href="<?php echo e(route('userKyc')); ?>" class="btn btn-success center-block">Submit Verification</a>

                        <?php else: ?>
                            <h5 class="card-title"><span class="text-danger">Identity Verify:   </span>
                                    <?php if($result1): ?>
                                        <?php if($result1->status == false): ?>
                                        <span class="btn btn-warning btn-sm">Under Review</span>
                                        <?php else: ?>
                                        <span class="btn btn-success btn-sm">Approved</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                    <span class="btn btn-info btn-sm">Not Yet Submit</span>
                                    <?php endif; ?>
                            </h5>
                            <br>
                            <h5 class="card-title"><span class="text-danger">Address Verify:    </span>

                                <?php if($result2): ?>
                                    <?php if($result2->status == false): ?>
                                        <span class="btn btn-warning btn-sm">Under Review</span>
                                    <?php else: ?>
                                        <span class="btn btn-success btn-sm">Approved</span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="btn btn-info btn-sm">Not Yet Submit</span>
                                <?php endif; ?>
                            </h5>
                            <br>

                            <?php if(count($identity) == 0 or count($address) == 0): ?>

                                <a href="<?php echo e(route('userKyc')); ?>" class="btn btn-success center-block">Submit Verification</a>

                            <?php elseif(count($identity) == 1 and count($address) == 1): ?>


                            <?php endif; ?>


                    <?php endif; ?>
                    </div>

                </div>
            </div>


        </div>



    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>