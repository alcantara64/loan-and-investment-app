<?php $__env->startSection('title', 'Write a review to us'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-8 col-md-offset-1">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="purple">
                    <i class="material-icons">face</i>
                </div>

                <div class="card-content">
                    <h4 class="card-title">User Testimonial Section -
                        <small class="category">Write a review to us</small>
                    </h4>
                    <br>

                    <?php if(count($review) == 0): ?>

                    <form action="<?php echo e(route('userReview.post')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger alert-with-icon" data-notify="container">
                                <i class="material-icons" data-notify="icon">notifications</i>
                                <span data-notify="message">

                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><strong> <?php echo e($error); ?> </strong></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </span>
                            </div>
                        <?php endif; ?>


                        <div class="row">

                            <div class="col-md-10">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="title">Subject</label>
                                    <input id="title" name="title" type="text" class="form-control">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-10">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="comment">Your Comment</label>
                                    <textarea name="comment" class="form-control" id="comment" rows="10"></textarea>
                                </div>
                            </div>
                        </div>
                        <br> <br>
                        <a href="<?php echo e(route('userDashboard')); ?>" class="btn btn-rose">Cancel Create</a>
                        <button type="submit" class="btn btn-success pull-right">Submit Review</button>
                        <div class="clearfix"></div>
                    </form>
                    <?php else: ?>

                    <h4 class="text-center text-success"> You are already submitted review</h4>

                    <?php endif; ?>

                </div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>