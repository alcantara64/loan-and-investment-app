<?php $__env->startSection('title', 'My Investments History'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="green">
                    <i class="material-icons">payment</i>
                </div>
                <br>
                <h4 class="card-title">My Investments History</h4>
                <div class="card-content">
                    <br>
                    <?php if(count($investments) > 0): ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th class="text-center">SN</th>
                                    <th class="text-center">Reference Id</th>
                                    <th class="text-center">Invest Type</th>
                                    <th class="text-center">Interest Rate</th>
                                    <th class="text-center">Interest System</th>
                                    <th class="text-center">Amount</th>
                                    <th class="text-center">Start Time</th>
                                    <th class="text-center">Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $id=0;?>
                                <?php $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $id++;?>
                                    <tr>
                                        <td class="text-center"><?php echo e($id); ?></td>
                                        <td class="text-center"><?php echo e($investment->reference_id); ?></td>
                                        <td class="text-center"><?php echo e($investment->plan->style->name); ?></td>
                                        <td class="text-center"><?php echo e($investment->plan->percentage +0); ?>%</td>
                                        <td class="text-center"><?php echo e($investment->plan->style->compound); ?> Hours Later <?php echo e($investment->plan->repeat); ?> Times</td>
                                        <td class="text-center"><?php echo e(config('app.currency_symbol')); ?> <?php echo e($investment->amount + 0); ?></td>
                                        <td class="text-center"><?php echo e($investment->start_time->diffForHumans()); ?></td>
                                        <td >
                                            <?php if($investment->status == 0): ?>

                                                <button class="btn btn-warning">
                                        <span class="btn-label">
                                            <i class="material-icons">check</i>
                                        </span>
                                                   Not Started Yet
                                                </button>


                                            <?php elseif($investment->status == 1): ?>

                                                <button class="btn btn-primary">
                                        <span class="btn-label">
                                            <i class="material-icons">warning</i>
                                        </span>
                                                    Running
                                                </button>
                                            <?php else: ?>
                                                <button class="btn btn-success">
                                        <span class="btn-label">
                                            <i class="material-icons">warning</i>
                                        </span>
                                                    Completed
                                                </button>

                                            <?php endif; ?>



                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>

                    <?php else: ?>

                        <h1 class="text-center">No Don't Have any Investment Yet</h1>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-5">

                            <?php echo e($investments->render()); ?>


                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>