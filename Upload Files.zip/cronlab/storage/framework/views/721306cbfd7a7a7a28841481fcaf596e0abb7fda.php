<?php $__env->startSection('title', 'All User Deposit Request'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">contacts</i>
                </div>
                <br>
                <h4 class="card-title">Deposit Request</h4>
                <div class="card-content">
                    <br>
                    <br>
                    <?php if(count($deposits) > 0): ?>
                        <div class="table-responsive">

                            <table class="table">
                                <thead>
                                <tr>
                                    <th class="text-center">SN</th>
                                    <th class="text-center">Transaction Id</th>
                                    <th class="text-center">Gateway</th>
                                    <th class="text-center">Amount</th>
                                    <th class="text-center">Details</th>
                                    <th class="text-center">Time</th>
                                    <th class="text-center">Set As</th>
                                    <th class="text-center">Set As</th>
                                    <th class="text-center">Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $id=0;?>
                                <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $id++;?>
                                    <tr>
                                        <td class="text-center"><?php echo e($id); ?></td>
                                        <td class="text-center"><?php echo e($deposit->transaction_id); ?></td>
                                        <td class="text-center"><?php echo e($deposit->gateway_name); ?></td>
                                        <td class="text-center"><?php echo e(config('app.currency_symbol')); ?> <?php echo e($deposit->amount); ?></td>
                                        <td class="text-center"><?php echo e($deposit->details); ?></td>
                                        <td class="text-center"><?php echo e($deposit->created_at->diffForHumans()); ?></td>
                                        <td class="text-center td-actions">

                                            <?php if($deposit->status == 0): ?>

                                                <a href="<?php echo e(route('admin.deposit.update', $deposit->id)); ?>" type="button" class="btn btn-success">
                                                    <i class="material-icons">edit</i> Complete
                                                </a>
                                            <?php endif; ?>

                                        </td>

                                        <td class="text-center td-actions">

                                            <?php if($deposit->status == 0): ?>
                                                <a href="<?php echo e(route('admin.deposit.fraud', $deposit->id)); ?>" type="button" class="btn btn-warning">
                                                    <i class="material-icons">edit</i> Fraud
                                                </a>
                                            <?php endif; ?>

                                        </td>

                                        <td class="text-center td-actions">

                                            <?php if($deposit->status == 1): ?>
                                                <button class="btn btn-success btn-sm">
                                        <span class="btn-label">
                                            <i class="material-icons">check</i>
                                        </span>Completed
                                                </button>

                                            <?php else: ?>

                                                <button class="btn btn-primary btn-sm">
                                        <span class="btn-label">
                                            <i class="material-icons">warning</i>
                                        </span>
                                                    Pending
                                                </button>
                                            <?php endif; ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>

                    <?php else: ?>

                        <h1 class="text-center">No Deposit Request</h1>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-5">

                            <?php echo e($deposits->render()); ?>


                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>