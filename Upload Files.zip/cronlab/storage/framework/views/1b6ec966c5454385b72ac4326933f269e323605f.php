<?php $__env->startSection('title', 'All Address Verify Request'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-9">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">contacts</i>
                </div>
                <br>
                <h4 class="card-title">All Address Verify Request</h4>


                <div class="card-content">

                    <br>


                    <div class="table-responsive">

                        <table class="table">
                            <thead>
                            <tr>
                                <th class="text-center">ID</th>
                                <th class="text-center">Type</th>
                                <th class="text-center">Name</th>
                                <th class="text-center">photo</th>
                                <th class="text-center">View</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php if($kycs): ?>

                                <?php $id=0;?>

                                <?php $__currentLoopData = $kycs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kyc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php $id++;?>

                                    <tr>
                                        <td class="text-center"><?php echo e($id); ?></td>
                                        <td class="text-center"><?php echo e($kyc->name); ?></td>
                                        <td class="text-center"><?php echo e($kyc->user->name); ?></td>
                                        <td width="20%" >
                                            <img src="<?php echo e($kyc->photo); ?>" class="img-rounded" alt="Front Page Photo"  >
                                        </td>
                                        <td class="td-actions text-center">
                                            <a href="<?php echo e(route('adminKyc2Show', $kyc->id)); ?>" type="button" rel="tooltip" class="btn btn-success">Show</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endif; ?>

                            </tbody>
                        </table>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-5">

                            <?php echo e($kycs->render()); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-md-3">
                <div class="card card-content">
                    <div class="card-content">
                        <form action="<?php echo e(route('admin.users.index')); ?>" method="get">
                            <div class="form-group label-floating">
                                <label for="s" class="control-label">Search</label>
                                <input type="text" id="s" name="s" value="<?php echo e(isset($s) ? $s : ''); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary ">Search</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>