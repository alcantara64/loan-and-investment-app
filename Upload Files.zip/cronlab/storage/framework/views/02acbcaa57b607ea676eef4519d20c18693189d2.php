<?php $__env->startSection('title', 'View All Available Ads'); ?>
<?php $__env->startSection('content'); ?>



    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="green">
                    <i class="material-icons">important_devices</i>
                </div>
                <br>
                <h4 class="card-title">All Available Ads</h4>
                <div class="card-content">
                    <br>

                    <?php if(count($adverts) > 0): ?>
                        <div class="table-responsive">

                            <table class="table">
                                <thead>
                                <tr>
                                    <th class="text-center">ID</th>
                                    <th>Ad Title</th>
                                    <th>Ad Rewards</th>
                                    <th>Status</th>
                                    <th>Action</th>

                                </tr>
                                </thead>
                                <tbody>

                                <?php $id=0;?>
                                <?php $__currentLoopData = $adverts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $id++;?>

                                    <tr>
                                        <td><?php echo e($id); ?></td>
                                        <td><?php echo e($advert->ptc->title); ?></td>
                                        <td><?php echo e(config('app.currency_symbol')); ?> <?php echo e($advert->ptc->rewards +0); ?></td>
                                        <td>
                                            <?php if($advert->status == 0): ?>
                                                <span class="btn btn-danger"><i class="material-icons">edit</i> Not Show</span>
                                            <?php else: ?>
                                                <span class="btn btn-primary"><i class="material-icons">edit</i> Viewed</span>
                                            <?php endif; ?>
                                        </td>

                                        <td >
                                            <?php if($advert->status == 0): ?>
                                                <a href="<?php echo e(route('userCashLinks.show', $advert->id)); ?>" type="button" rel="tooltip" class="btn btn-info">
                                                    <i class="material-icons">edit</i>
                                                    View Ads
                                                </a>
                                            <?php else: ?>
                                                <span class="btn btn-primary"><i class="material-icons">edit</i> Viewed</span>
                                            <?php endif; ?>
                                        </td>



                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>

                            </table>



                        </div>
					<?php else: ?>

                        <h1 class="text-center">No Advertisement Right Now</h1>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-5">

                            <?php echo e($adverts->render()); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>