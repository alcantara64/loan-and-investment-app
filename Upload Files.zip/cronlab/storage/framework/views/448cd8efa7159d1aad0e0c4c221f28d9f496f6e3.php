<?php $__env->startSection('title', 'Sign Up For Earn Cash'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-5 col-md-offset-4 col-sm-6 col-sm-offset-3">
                <div class="card card-signup">

                    <div class="header header-info text-center">
                        <h4 class="card-title">Sign Up For Full Features</h4>
                        <div class="social-line">
                            <a href="<?php echo e(route('social.auth', ['provider'=>'facebook'])); ?>" class="btn btn-just-icon btn-simple">
                                <i class="fa fa-facebook-square"></i>
                            </a>
                            <a href="" class="btn btn-just-icon btn-simple">
                                <i class="fa fa-twitter"></i>
                            </a>
                            <a href="" class="btn btn-just-icon btn-simple">
                                <i class="fa fa-google-plus"></i>
                            </a>
                        </div>
                    </div>
                    <p class="description text-center">Or Be Classical</p>
                    <div class="row">
                        <div class="card-content">

                        <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">

                            <?php echo e(csrf_field()); ?>


                            <div class="card-content">
                                <div class="input-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
											<span class="input-group-addon">
												<i class="material-icons">face</i>
											</span>
                                    <div class="form-group label-floating">
                                        <label class="control-label" for="name">Full Name</label><input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                    </div>
                                </div>

                                <div class="input-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
											<span class="input-group-addon">
												<i class="material-icons">email</i>
											</span>
                                    <div class="form-group label-floating">
                                    <label class="control-label" for="email">Email Address</label><input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                    </div>
                                </div>

                                <div class="input-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
											<span class="input-group-addon">
												<i class="material-icons">lock_outline</i>
											</span>
                                    <div class="form-group label-floating">
                                    <label class="control-label" for="password">Password</label><input id="password" type="password" class="form-control" name="password" required>

                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                    </div>
                                </div>
                                <div class="input-group">
											<span class="input-group-addon">
												<i class="material-icons">lock_outline</i>
											</span>
                                    <div class="form-group label-floating">
                                    <label class="control-label" for="password-confirm">Password Confirm</label><input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                    </div>
                                </div>

                                <!-- If you want to add a checkbox to this form, uncomment this code -->

                                
                                
                                
                                
                                
                                
                            </div>
                            <div class="input-group col-md-3 col-md-offset-2">

                                <?php echo Recaptcha::render(); ?>


                            </div>
                            <div class="footer text-center">
                                <button type="submit" class="btn btn-info">
                                    <i class="material-icons">input</i> Register Now
                                </button>

                                <a class="btn btn-warning" href="<?php echo e(route('login')); ?>">
                                    <i class="material-icons">warning</i> Already Account? Login Here
                                </a>
                            </div>
                        </form>
                    </div>

                    </div>


                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>