<?php $__env->startSection('title', 'View All Invest Plan'); ?>


<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">contacts</i>
                </div>
                <br>
                <h4 class="card-title">All Invest Plan</h4>
                <div class="card-content">
                    <br>

                    <?php if(count($plans) > 0): ?>

                        <div class="table-responsive">

                            <table class="table">
                                <thead>
                                <tr>
                                    <th class="text-center">ID</th>
                                    <th class="text-center">Name</th>
                                    <th class="text-center">Type</th>
                                    <th class="text-center">Minimum</th>
                                    <th class="text-center">Maximum</th>
                                    <th class="text-center">Interest</th>
                                    <th class="text-center">Interest System</th>
                                    <th class="text-center">Start Time</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Edit</th>
                                    <th class="text-center">Action</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $id=0;?>
                                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $id++;?>
                                    <tr>
                                        <td class="text-center"><?php echo e($id); ?></td>
                                        <td class="text-center"><?php echo e($plan->name); ?></td>
                                        <td class="text-center"><?php echo e($plan->style->name); ?></td>
                                        <td class="text-center"><?php echo e(config('app.currency_symbol')); ?> <?php echo e($plan->minimum + 0); ?></td>
                                        <td class="text-center"><?php echo e(config('app.currency_symbol')); ?> <?php echo e($plan->maximum + 0); ?></td>
                                        <td class="text-center"><?php echo e($plan->percentage); ?>%</td>
                                        <td class="text-center"><?php echo e($plan->style->compound); ?> Hours Later <?php echo e($plan->repeat); ?> Times</td>
                                        <td class="text-center"><?php echo e($plan->start_duration); ?> Hours After Invest</td>
                                        <td class="text-center"><?php echo e($plan->status == 1 ? 'Active':'Not Active'); ?></td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('adminInvest.edit', $plan->id)); ?>" type="button" class="btn btn-success">
                                                <i class="material-icons">edit</i>
                                            </a>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('adminInvest.delete', $plan->id)); ?>" type="button" class="btn btn-danger">
                                                <i class="material-icons">close</i>

                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>

                        </div>

                    <?php else: ?>

                        <h1 class="text-center">No Invest Plan Found</h1>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>