<?php $__env->startSection('title', 'All PPV Advertisement'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="rose">
                    <i class="material-icons">contacts</i>
                </div>
                <br>
                <h4 class="card-title">All PPV Advertisement</h4>
                <div class="card-content">
                    <br>
					
						<?php if(count($advertisements) > 0): ?>

                    <div class="table-responsive">

                        


                        <table class="table">
                            <thead>
                            <tr>
                                <th class="text-center">ID</th>
                                <th class="text-center">Title</th>
                                <th class="text-center">Details</th>
                                <th class="text-center">CodeL</th>
                                <th class="text-center">Membership</th>
                                <th class="text-center">Per Click</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Edit</th>
                                <th class="text-right">Actions</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $id=0;?>
                                <?php $__currentLoopData = $advertisements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertisement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $id++;?>
                                    <tr>
                                        <td class="text-center"><?php echo e($id); ?></td>
                                        <td class="text-center"><?php echo e($advertisement->title); ?></td>
                                        <td class="text-center"><?php echo $advertisement->details; ?></td>
                                        <td class="text-center"><?php echo e($advertisement->code); ?></td>
                                        <td class="text-center"><?php echo e($advertisement->membership->name); ?></td>
                                        <td class="text-center">$ <?php echo e($advertisement->rewards + 0); ?></td>
                                        <td class="text-center"><?php echo e($advertisement->status == 1 ? 'Active':'Not Active'); ?></td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('admin.ppv.edit', $advertisement->id)); ?>" type="button" rel="tooltip" class="btn btn-info">
                                                <i class="material-icons">edit</i>

                                            </a>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('admin.ppv.delete', $advertisement->id)); ?>" type="button" rel="tooltip" class="btn btn-danger">
                                                <i class="material-icons">close</i>

                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







                            </tbody>
                        </table>




                    </div>

                    <?php else: ?>

                        <h1 class="text-center">No Advertisements</h1>

                    <?php endif; ?>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-5">

                            <?php echo e($advertisements->render()); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>