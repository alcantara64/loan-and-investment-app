<?php $__env->startSection('title', 'Edit Payment Gateway'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="purple">
                    <i class="material-icons">face</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">Gateway Section -
                        <small class="category">Edit Gateway</small>
                    </h4>

                    <form action="<?php echo e(route('admin.gateway.update',['id'=>$gateway->id])); ?>" method="post" enctype="multipart/form-data">

                        <?php echo e(csrf_field()); ?>


                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger alert-with-icon" data-notify="container">
                                <i class="material-icons" data-notify="icon">notifications</i>
                                <span data-notify="message">

                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><strong> <?php echo e($error); ?> </strong></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </span>
                            </div>
                        <?php endif; ?>


                    <div class="row">

                        <div class="col-md-12">
                            <div class="form-group label-floating">

                                <label  class="control-label" for="name">Gateway Name</label>
                                <input id="name" name="name" type="text" value="<?php echo e($gateway->name); ?>" class="form-control">

                            </div>
                        </div>
                    </div>
                        <br>
                        <div class="row">
                            <div class="col-md-6 col-md-offset-3">
                                <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                    <div class="fileinput-new thumbnail">
                                        <img src="<?php echo e(asset($gateway->image)); ?>" alt="...">
                                    </div>
                                    <div class="fileinput-preview fileinput-exists thumbnail"></div>
                                    <div>
                                                    <span class="btn btn-rose btn-round btn-file">
                                                        <span class="fileinput-new">Select Gateway Logo</span>
                                                        <span class="fileinput-exists">Change Gateway Logo</span>
                                                      <input type="file" name="image" />
                                                    </span>
                                        <a href="#" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group label-floating">
                                    <select class="selectpicker" name="status" data-style="btn btn-warning btn-round" title="Select Status" data-size="7">

                                        <option value="0"
                                                <?php if($gateway->status == 0): ?>
                                                selected
                                                <?php endif; ?>
                                        >Not Active</option>
                                        <option value="1"
                                                <?php if($gateway->status == 1): ?>
                                                selected
                                                <?php endif; ?>

                                        >Already Active</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group label-floating">
                                <label  class="control-label" for="account">Gateway Account Name</label>
                                <input id="account" name="account" type="text" value="<?php echo e($gateway->account); ?>" class="form-control">
                            </div>
                        </div>
                    </div>
                    <br>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group label-floating">
                                    <label  class="control-label" for="fixed">Gateway Fixed Fee</label>
                                    <input id="fixed" name="fixed" type="text" value="<?php echo e($gateway->fixed); ?>" class="form-control">
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group label-floating">

                                    <label  class="control-label" for="percent">Gateway Percentage Fee</label>
                                    <input id="percent" name="percent" type="text" value="<?php echo e($gateway->percent); ?>" class="form-control">

                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group label-floating">

                                    <label  class="control-label" for="ex_percent">Currency Exchange Percentage Fee</label>
                                    <input id="ex_percent" name="ex_percent" type="text" value="<?php echo e($gateway->ex_percent); ?>" class="form-control">

                                </div>
                            </div>
                        </div>
                        <br>
                            <div class="row">

                                <div class="col-md-12">
                                    <div class="form-group label-floating">

                                        <label  class="control-label" for="val1">Gateway Client Id</label>
                                        <input id="val1" name="val1" type="text" value="<?php echo e($gateway->val1); ?>" class="form-control">

                                    </div>
                                </div>
                            </div>
                        <br>
                            <div class="row">

                                <div class="col-md-12">
                                    <div class="form-group label-floating">

                                        <label  class="control-label" for="val2">Gateway Secret Info</label>
                                        <input id="val2" name="val2" type="text" value="<?php echo e($gateway->val2); ?>" class="form-control">

                                    </div>
                                </div>
                            </div>
                        <br>

                    <a href="<?php echo e(route('admin.gateways.index')); ?>" class="btn btn-rose">Cancel Edit</a>
                        <button type="submit" class="btn btn-success pull-right">Save Changes</button>

                        <div class="clearfix"></div>
                    </form>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>