<?php $__env->startSection('title', 'Pick the best plan for you'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="row">
                    <div class="text-center">
                        <h5 class="title text-danger">Read this before submit</h5>
                    </div>
                </div>

                <div class="card-content">
                    <br>
                    <h4>The following documents are accepted for verification of identity:</h4>
                    <ul>
                        <li>International passport</li>
                        <li>National ID card</li>
                        <li>Driver license</li>
                    </ul>
                    <br>
                    <h4>The following documents are not accepted for verification of identity:</h4>
                    <ul>
                        <li>Voter's card</li>
                        <li>Residence permit (only as addition to other documents)</li>
                        <li>Health insurance card</li>
                        <li>Professional ID cards</li>
                        <li>Student ID cards</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="row">
                    <div class="text-center">
                        <h5 class="title text-danger">Read this before submit</h5>
                    </div>
                </div>

                <div class="card-content">
                    <br>

                    <h4> For address verification are accepted the following documents:</h4>
                    <ul>
                        <li>Utility bills (water bill, electricity bill, gas bill, etc.)</li>
                        <li>Bank statement</li>
                        <li>Mobile phone bill</li>
                        <li>Cable bill</li>
                        <li>Credit card statement, etc.</li>
                    </ul>
                    <h5>Utility bill / bank statement or any other bill provided for verification has to match the following criteria:</h5>
                    <ul>
                        <li>It has to be a copy of paper (not online) bill</li>
                        <li>Bill has to be in the name of the user</li>
                        <li>Bill has to contain user address</li>
                        <li>Bill has to contain date (for the last 2 months).</li>

                    </ul>


                </div>
            </div>
        </div>

    </div>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <h3 class="title text-center">Fill the form with your real information</h3>
            <br />
            <div class="nav-center">
                <ul class="nav nav-pills nav-pills-info nav-pills-icons" role="tablist">
                    <?php if($result1): ?>

                    <?php else: ?>
                    <li class="active">
                        <a href="#identity" role="tab" data-toggle="tab">
                            <i class="material-icons">gavel</i> Identity Verify
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if($result2): ?>


                    <?php else: ?>
                    <li>
                        <a href="#paddress" role="tab" data-toggle="tab">
                            <i class="material-icons">location_on</i> Proof of Address
                        </a>
                    </li>

                    <?php endif; ?>
                </ul>
            </div>
            <div class="tab-content">
                <?php if($result1): ?>

                <?php else: ?>
                <div class="tab-pane active" id="identity">
                    <div class="card">
                        <div class="card-content">
                            <form action="<?php echo e(route('userKyc.submit')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <?php if(count($errors) > 0): ?>
                                    <div class="alert alert-danger alert-with-icon" data-notify="container">
                                        <i class="material-icons" data-notify="icon">notifications</i>
                                        <span data-notify="message">

                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><strong> <?php echo e($error); ?> </strong></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </span>
                                    </div>
                                <?php endif; ?>

                                <br><br>
                                <div class="alert alert-info">
                                    <span>If you select Passport as Document Type then you don't have to upload second page</span>
                                </div>
                                <div class="row">
                                        <div class="col-md-6 col-md-offset-3">
                                            <div class="form-group label-floating">
                                                <select class="selectpicker" name="name" data-style="btn btn-warning btn-round" title="Select Document Type" data-size="7">
                                                    <option value="National ID Card">National ID Card</option>
                                                    <option value="International Passport">International Passport</option>
                                                    <option value="Driver License">Driver License</option>
                                                </select>
                                            </div>
                                        </div>
                                </div>
                                <br><br>
                                <div class="row">
                                    <div class="col-md-6">

                                        <div class="form-group label-floating">
                                            <label  class="control-label" for="number">Passport/NID/Driver License Number</label>
                                            <input id="number" name="number" type="text" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group label-floating">
                                            <label  class="control-label" for="dob">Date of Birth</label>
                                            <input id="dob" name="dob" type="date" class="form-control">
                                        </div>
                                    </div>

                                </div>
                                <br><br>
                                <div class="row">
                                    <div class="col-md-6 col-md-offset-3">
                                        <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                            <div class="fileinput-new thumbnail">
                                                <img src="<?php echo e(asset('img/image_placeholder.jpg')); ?>" alt="...">
                                            </div>
                                            <div class="fileinput-preview fileinput-exists thumbnail"></div>
                                            <div>
                                                    <span class="btn btn-rose btn-round btn-file">
                                                        <span class="fileinput-new">Select Front Page</span>
                                                        <span class="fileinput-exists">Change Front Page</span>
                                                        <input type="file" name="front" />
                                                    </span>
                                                <a href="#" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <br><br>
                                <div class="row">
                                    <div class="col-md-6 col-md-offset-3">
                                        <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                            <div class="fileinput-new thumbnail">
                                                <img src="<?php echo e(asset('img/image_placeholder.jpg')); ?>" alt="...">
                                            </div>
                                            <div class="fileinput-preview fileinput-exists thumbnail"></div>
                                            <div>
                                                    <span class="btn btn-rose btn-round btn-file">
                                                        <span class="fileinput-new">Select Back Page</span>
                                                        <span class="fileinput-exists">Change Back Page</span>
                                                        <input type="file" name="back" />
                                                    </span>
                                                <a href="#" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <br><br>


                                <a href="<?php echo e(route('userDashboard')); ?>" class="btn btn-rose">Cancel Verify</a>
                                <button type="submit" class="btn btn-success pull-right">Submit Verification</button>
                                <div class="clearfix"></div>
                            </form>




                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($result2): ?>


                <?php else: ?>
                        <div class="tab-pane" id="paddress">
                    <div class="card">
                        <div class="card-content">

                            <form action="<?php echo e(route('userKyc2.submit')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <?php if(count($errors) > 0): ?>
                                    <div class="alert alert-danger alert-with-icon" data-notify="container">
                                        <i class="material-icons" data-notify="icon">notifications</i>
                                        <span data-notify="message">

                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><strong> <?php echo e($error); ?> </strong></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </span>
                                    </div>
                                <?php endif; ?>

                                <br><br>
                                <div class="row">
                                    <div class="col-md-6 col-md-offset-3">
                                        <div class="form-group label-floating">
                                            <select class="selectpicker" name="name" data-style="btn btn-warning btn-round" title="Select Document Type" data-size="7">
                                                <option value="Bank Statement">Bank Statement</option>
                                                <option value="Utility Bills">Utility Bills</option>
                                                <option value="Credit Card Statement">Credit Card Statement</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <br><br>
                                <div class="row">
                                    <div class="col-md-6 col-md-offset-3">
                                        <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                            <div class="fileinput-new thumbnail">
                                                <img src="<?php echo e(asset('img/image_placeholder.jpg')); ?>" alt="...">
                                            </div>
                                            <div class="fileinput-preview fileinput-exists thumbnail"></div>
                                            <div>
                                                    <span class="btn btn-rose btn-round btn-file">
                                                        <span class="fileinput-new">Select Back Page</span>
                                                        <span class="fileinput-exists">Change Back Page</span>
                                                        <input type="file" name="photo" />
                                                    </span>
                                                <a href="#" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <br><br>


                                <a href="<?php echo e(route('userDashboard')); ?>" class="btn btn-rose">Cancel Verify</a>
                                <button type="submit" class="btn btn-success pull-right">Submit Verification</button>
                                <div class="clearfix"></div>
                            </form>



                        </div>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>