

<div class="container">
    <nav class="pull-left">
        <ul>
            <li>
                <a href="<?php echo e(route('contact')); ?>">
                    Contact Us
                </a>
            </li>
            <?php if($aml->status == 1): ?>
                <li>
                    <a href="<?php echo e(route('viewPage', $aml->slug)); ?>">
                        AML Policy
                    </a>
                </li>
            <?php endif; ?>
            <?php if($kyc->status == 1): ?>
                <li>
                    <a href="<?php echo e(route('viewPage', $kyc->slug)); ?>">
                        KYC Policy
                    </a>
                </li>
            <?php endif; ?>
            <?php if($pp->status == 1): ?>
                <li>
                    <a href="<?php echo e(route('viewPage', $pp->slug)); ?>">
                        Privacy Policy
                    </a>
                </li>
            <?php endif; ?>
            <?php if($tos->status == 1): ?>
                <li>
                    <a href="<?php echo e(route('viewPage', $tos->slug)); ?>">
                        Terms and Conditions
                    </a>
                </li>
            <?php endif; ?>
            <?php if($settings->payment_proof == 1): ?>
                <li>
                    <a href="<?php echo e(route('paymentProof')); ?>">
                        Payment Proof
                    </a>
                </li>
            <?php endif; ?>

        </ul>
    </nav>
    <div class="copyright pull-right">
        &copy; By <?php echo e(config('app.name')); ?> <?php echo e(date('Y')); ?>. Developed By <i class="fa fa-heart heart"></i> <a href="<?php echo e(config('app.dev_url')); ?>"><?php echo e(config('app.dev_company')); ?></a>
    </div>
</div>